-- Static semantic reconstruction of the business payload only.
-- This is NOT the original source text. Identifier names and expression history
-- cannot be recovered uniquely from the supplied representation.
-- The obfuscator's environment checks, anti-hook traps, and loaders are omitted.
-- Neither the uploaded Lua nor its decoded code was executed during analysis.

print(12)
